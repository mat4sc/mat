
import json
import os
import warnings

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import Dataset
from transformers import AutoConfig, AutoModel, AutoTokenizer, Trainer, TrainingArguments, set_seed
from transformers.trainer_utils import get_last_checkpoint

warnings.filterwarnings("ignore")

# ============================================================================
# CONFIGURATION
# ============================================================================

DATASET = "hmof"  # "qmof" or "hmof"

DESCRIPTORS = {
    "metal_ligand_geometry": True,  
    "metal_coordination": True,     
    "bond_connectivity": True,       
    "pore_structure": True,        
    "top_pore": False,                # 2 features: Key pore features (subset of pore_structure) ## only use it as standalone, do not enable other descriptors with it
}

LLM_MODEL = "ibm-granite/granite-4.0-350m"
#LLM_MODEL = "ibm-granite/granite-3.3-2b-instruct"

DATA_DIR = os.path.dirname(os.path.abspath(__file__))  # folder containing this script and {DATASET}.csv
MAX_LENGTH = 512

NUM_EPOCHS = 100
BATCH_SIZE = 24
EVAL_BATCH_SIZE = 32
LEARNING_RATE = 3e-5
WEIGHT_DECAY = 0.01
WARMUP_STEPS = 100
LOGGING_STEPS = 3000
EVAL_STEPS = 3000
SAVE_STEPS = 3000
NUM_WORKERS = 8
BF16 = True
SEED = 42


FUSION = {
    "fusion_dim": 1024,
    "num_attention_heads": 16,
    "num_layers": 6,
    "ffn_dim": 4096,
    "ffn_dropout": 0.1,
    "layernorm_eps": 1e-5,
}
HEAD = {"hidden_dims": [512, 128], "dropout": 0.05}

# ============================================================================
# TASKS AND DESCRIPTOR COLUMNS
# ============================================================================

TARGETS = {
    "qmof": ["band_gap"],
    "hmof": ["CH4_0.05", "CH4_0.5", "CH4_2.5", "CO2_0.05", "CO2_0.5", "CO2_2.5"],
}


CATEGORY_KEYS = {
    "metal_ligand_geometry": ["metal_ligand_dist_min", "metal_ligand_dist_mean", "metal_ligand_dist_max"],
    "metal_coordination": ["coord_number_min", "coord_number_max", "coord_number_mean", "coord_number_std"],
    "bond_connectivity": ["co_bond_count", "metal_o_bond_count", "cc_bond_count",
                         "metal_n_bond_count", "cn_bond_count"],
    "pore_structure": ["accessible_volume", "accessible_surface_area", "largest_cavity_diameter",
                       "largest_free_sphere", "pore_limiting_diameter", "void_fraction"],
    "top_pore": ["accessible_volume", "accessible_surface_area"],
}


def descriptor_keys():
    if DESCRIPTORS.get("pore_structure") and DESCRIPTORS.get("top_pore"):
        raise ValueError("Enable only one of 'pore_structure' and 'top_pore' (top_pore is a subset).")
    unknown = set(DESCRIPTORS) - set(CATEGORY_KEYS)
    if unknown:
        raise ValueError(f"Unknown descriptor categories: {sorted(unknown)}")
    keys = [k for cat in CATEGORY_KEYS if DESCRIPTORS.get(cat) for k in CATEGORY_KEYS[cat]]
    if not keys:
        raise ValueError("Enable at least one descriptor category.")
    return keys


def output_dir_name():
    llm = [p for p in LLM_MODEL.rstrip("/").split("/") if not p.startswith("checkpoint")][-1]
    llm = llm.replace("-", "_").replace(".", "_")
    flags = "".join("1" if DESCRIPTORS.get(c) else "0" for c in
                    ("metal_ligand_geometry", "metal_coordination", "bond_connectivity"))
    flags += "1" if (DESCRIPTORS.get("pore_structure") or DESCRIPTORS.get("top_pore")) else "0"
    suffix = "_top_pore" if DESCRIPTORS.get("top_pore") else ""
    return f"{llm}_{DATASET.upper()}_{NUM_EPOCHS}E_{BATCH_SIZE}Batch_{flags}{suffix}_seed{SEED}"


# ============================================================================
# DATASET
# ============================================================================

class MOFDataset(Dataset):

    def __init__(self, split, tokenizer, keys):
        table = pd.read_csv(os.path.join(DATA_DIR, f"{DATASET}.csv"))
        data = table[table["split"] == split].reset_index(drop=True)
        if data.empty:
            raise ValueError(f"No rows with split == '{split}' in {DATASET}.csv")
        absent = [c for c in keys + TARGETS[DATASET] + ["mof_id"] if c not in data.columns]
        if absent:
            raise ValueError(f"{DATASET}.csv is missing columns: {absent}")

        missing = int(data[keys].isna().any(axis=1).sum())
        if missing:
            raise ValueError(f"{missing} of {len(data)} {split} rows have no descriptors in {DATASET}.csv")
        bond_cols = [k for k in CATEGORY_KEYS["bond_connectivity"] if k in keys]
        if bond_cols and (data[bond_cols] == 0).all().all():
            raise ValueError(f"error")

        targets = TARGETS[DATASET]
        labels = data[targets].to_numpy(np.float32)
        self.mof_ids = data["mof_id"].astype(str).tolist()
        self.descriptors = torch.tensor(data[keys].to_numpy(np.float32))
        self.labels = torch.tensor(labels[:, 0] if len(targets) == 1 else labels)
        self.tokenizer = tokenizer

    def __len__(self):
        return len(self.mof_ids)

    def __getitem__(self, idx):
        enc = self.tokenizer(self.mof_ids[idx], max_length=MAX_LENGTH, padding="max_length",
                             truncation=True, return_tensors="pt")
        return {
            "input_ids": enc["input_ids"].squeeze(0),
            "attention_mask": enc["attention_mask"].squeeze(0),
            "descriptors": self.descriptors[idx],
            "labels": self.labels[idx],
        }


# ============================================================================
# MODEL
# ============================================================================

class FusionAdapterNetwork(nn.Module):


    def __init__(self, llm_hidden_size, descriptor_dim):
        super().__init__()
        d, eps = FUSION["fusion_dim"], FUSION["layernorm_eps"]
        self.descriptor_proj = nn.Sequential(nn.Linear(descriptor_dim, d), nn.LayerNorm(d, eps=eps))
        self.llm_proj = nn.Sequential(nn.Linear(llm_hidden_size, d), nn.LayerNorm(d, eps=eps))
        self.transformer_layers = nn.ModuleList()
        for _ in range(FUSION["num_layers"]):
            self.transformer_layers.append(nn.ModuleDict({
                "cross_attn": nn.MultiheadAttention(d, FUSION["num_attention_heads"], dropout=0.0, batch_first=True),
                "norm_cross": nn.LayerNorm(d, eps=eps),
                "ffn": nn.Sequential(
                    nn.Linear(d, FUSION["ffn_dim"]), nn.GELU(), nn.Dropout(FUSION["ffn_dropout"]),
                    nn.Linear(FUSION["ffn_dim"], d), nn.Dropout(0.0),
                ),
                "norm_ffn": nn.LayerNorm(d, eps=eps),
            }))
        self.output_dim = d

    def forward(self, llm_embeddings, descriptors, attention_mask):
        query = self.descriptor_proj(descriptors).unsqueeze(1)   # (B, 1, D)
        tokens = self.llm_proj(llm_embeddings)                   # (B, L, D)
        padding = attention_mask == 0                            # True at padding tokens
        for layer in self.transformer_layers:
            attn_out, _ = layer["cross_attn"](layer["norm_cross"](query), tokens, tokens,
                                              key_padding_mask=padding)
            query = query + attn_out
            query = query + layer["ffn"](layer["norm_ffn"](query))
        return query.squeeze(1)                                  # (B, D)


class MOFPredictor(nn.Module):
    def __init__(self, descriptor_dim, num_outputs):
        super().__init__()
        print(f"Loading LLM: {LLM_MODEL}")
        self.llm = AutoModel.from_pretrained(LLM_MODEL)
        hidden_size = AutoConfig.from_pretrained(LLM_MODEL).hidden_size
        for p in self.llm.parameters():
            p.requires_grad = False  # the LLM is always frozen

        self.fusion_adapter = FusionAdapterNetwork(hidden_size, descriptor_dim)
        dims = [self.fusion_adapter.output_dim] + HEAD["hidden_dims"]
        layers = [nn.LayerNorm(dims[0])]
        for i in range(len(dims) - 1):
            layers += [nn.Linear(dims[i], dims[i + 1]), nn.GELU(), nn.Dropout(HEAD["dropout"])]
        layers.append(nn.Linear(dims[-1], num_outputs))
        self.regression_head = nn.Sequential(*layers)

        trainable = sum(p.numel() for p in self.parameters() if p.requires_grad)
        print(f"Trainable parameters: {trainable:,} | outputs: {num_outputs}")

    def forward(self, input_ids, attention_mask, descriptors):
        tokens = self.llm(input_ids=input_ids, attention_mask=attention_mask).last_hidden_state
        fused = self.fusion_adapter(tokens, descriptors, attention_mask)
        return self.regression_head(fused).squeeze(-1)


# ============================================================================
# TRAINING AND EVALUATION
# ============================================================================

class MOFTrainer(Trainer):
    """MSE loss on the raw targets."""

    def compute_loss(self, model, inputs, return_outputs=False, *, num_items_in_batch=None):
        labels = inputs.pop("labels")
        outputs = model(**inputs)
        loss = torch.nn.functional.mse_loss(outputs, labels)
        return (loss, outputs) if return_outputs else loss

    def prediction_step(self, model, inputs, prediction_loss_only, ignore_keys=None):
        labels = inputs.pop("labels")
        with torch.no_grad():
            outputs = model(**inputs)
            loss = torch.nn.functional.mse_loss(outputs, labels)
        return (loss, outputs, labels)


def make_compute_metrics(targets):
    def compute_metrics(eval_pred):
        preds, labels = eval_pred
        preds = np.asarray(preds, dtype=np.float64).reshape(len(labels), -1)
        labels = np.asarray(labels, dtype=np.float64).reshape(len(labels), -1)
        err = preds - labels
        task_mae = np.abs(err).mean(axis=0)  # one MAE per target
        mse = float((err ** 2).mean())
        r2 = 1.0 - (err ** 2).sum() / ((labels - labels.mean()) ** 2).sum()
        metrics = {"mae": float(task_mae.mean()), "mse": mse, "rmse": mse ** 0.5, "r2": float(r2)}
        if len(targets) > 1:
            metrics.update({f"mae_{name}": float(m) for name, m in zip(targets, task_mae)})
        return metrics
    return compute_metrics


def main():
    if DATASET not in TARGETS:
        raise ValueError(f"DATASET must be one of {list(TARGETS)}, got '{DATASET}'")
    keys = descriptor_keys()
    targets = TARGETS[DATASET]
    out_dir = output_dir_name()
    is_main = int(os.environ.get("RANK", 0)) == 0

    set_seed(SEED)
    if is_main:
        print(f"Dataset: {DATASET} | targets: {targets}")
        print(f"Descriptors ({len(keys)}): {keys}")
        print(f"Output directory: {out_dir}")
    os.makedirs(out_dir, exist_ok=True)

    tokenizer = AutoTokenizer.from_pretrained(LLM_MODEL)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    train_ds = MOFDataset("train", tokenizer, keys)
    valid_ds = MOFDataset("valid", tokenizer, keys)
    test_ds = MOFDataset("test", tokenizer, keys)
    if is_main:
        print(f"Samples: train={len(train_ds)} valid={len(valid_ds)} test={len(test_ds)}")

    model = MOFPredictor(descriptor_dim=len(keys), num_outputs=len(targets))

    args = TrainingArguments(
        output_dir=out_dir,
        num_train_epochs=NUM_EPOCHS,
        per_device_train_batch_size=BATCH_SIZE,
        per_device_eval_batch_size=EVAL_BATCH_SIZE,
        learning_rate=LEARNING_RATE,
        weight_decay=WEIGHT_DECAY,
        warmup_steps=WARMUP_STEPS,
        logging_steps=LOGGING_STEPS,
        eval_strategy="steps",
        eval_steps=EVAL_STEPS,
        save_strategy="steps",
        save_steps=SAVE_STEPS,
        save_total_limit=1,
        bf16=torch.cuda.is_available() and BF16,
        dataloader_num_workers=NUM_WORKERS,
        remove_unused_columns=False,
        report_to="tensorboard",
        seed=SEED,
        ddp_find_unused_parameters=False,
    )
    trainer = MOFTrainer(
        model=model,
        args=args,
        train_dataset=train_ds,
        eval_dataset=valid_ds,  # evaluation during training uses the validation split
        compute_metrics=make_compute_metrics(targets),
    )

    trainer.train(resume_from_checkpoint=get_last_checkpoint(out_dir))

    trainer.save_model(os.path.join(out_dir, "final_model"))
    if is_main:
        tokenizer.save_pretrained(os.path.join(out_dir, "final_model"))

    # Final evaluation on the test split, after the last epoch.
    test_metrics = trainer.evaluate(eval_dataset=test_ds, metric_key_prefix="test")
    if is_main:
        print("\nTEST RESULTS")
        for name, value in test_metrics.items():
            print(f"  {name}: {value}")
        with open(os.path.join(out_dir, "test_results.json"), "w") as f:
            json.dump({"dataset": DATASET, "descriptor_keys": keys, "test": test_metrics}, f, indent=2)


if __name__ == "__main__":
    main()
