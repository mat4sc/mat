
import json
import os
import re

import numpy as np
import pandas as pd
import torch
from datasets import Dataset as HF_Dataset
from tqdm import tqdm
from transformers import AutoModelForCausalLM, AutoTokenizer, TrainerCallback, pipeline
from transformers.trainer_utils import get_last_checkpoint
from trl import SFTConfig, SFTTrainer

os.environ["WANDB_MODE"] = "disabled"

# ============================================================================
# CONFIGURATION
# ============================================================================

DATASET = "hmof"  # "qmof" or "hmof"
MODEL_ID = "ibm-granite/granite-4.0-350m"
#MODEL_ID = "ibm-granite/granite-3.3-2b-instruct"


SEED = 42
NUM_TRAIN_EPOCHS = 5
TRAIN_BATCH_SIZE = 16
EVAL_BATCH_SIZE = 32
LEARNING_RATE = 3e-5
WARMUP_STEPS = 0
MAX_LENGTH = 512
MAX_NEW_TOKENS = 256
GRADIENT_CHECKPOINTING = True

DATA_DIR = os.path.dirname(os.path.abspath(__file__))  # folder containing this script and {DATASET}.csv
PROPERTIES = {
    "qmof": ["band_gap"],
    "hmof": ["CH4_0.5", "CH4_0.05", "CH4_2.5", "CO2_0.5", "CO2_0.05", "CO2_2.5"],
}
OUTPUT_DIR = f"./{MODEL_ID.rstrip('/').split('/')[-2]}_{DATASET.upper()}_{SEED}"
RESULTS_FILE = os.path.join(OUTPUT_DIR, "Output-Results.txt")

# ============================================================================
# DATA
# ============================================================================


def make_label(row):

    if DATASET == "qmof":
        return str(row["band_gap"])
    return "".join(f"<{p}>{row[p]}</{p}>" for p in PROPERTIES[DATASET])


def load_splits():

    table = pd.read_csv(os.path.join(DATA_DIR, f"{DATASET}.csv"))
    absent = [c for c in ["mof_id", "split"] + PROPERTIES[DATASET] if c not in table.columns]
    if absent:
        raise ValueError(f"{DATASET}.csv is missing columns: {absent}")
    splits = {}
    for split in ("train", "valid", "test"):
        rows = table[table["split"] == split].to_dict("records")
        if not rows:
            raise ValueError(f"No rows with split == '{split}' in {DATASET}.csv")
        splits[split] = [(str(r["mof_id"]), make_label(r)) for r in rows]
        print(f"{split}: {len(rows)} samples")
    return splits


# ============================================================================
# METRICS
# ============================================================================


def parse_values(text):

    text = str(text).strip()
    if DATASET == "qmof":
        try:
            return [float(text)]
        except ValueError:
            return None
    values = []
    for prop in PROPERTIES[DATASET]:
        match = re.search(fr"<{re.escape(prop)}>(.*?)</{re.escape(prop)}>", text, re.DOTALL)
        if not match:
            return None
        numbers = re.findall(r"-?\d+\.?\d*", match.group(1))
        if not numbers:
            return None
        values.append(float(numbers[0]))
    return values


def compute_mae(predictions, actuals):

    errors, invalid = [], 0
    for pred, actual in zip(predictions, actuals):
        p, a = parse_values(pred), parse_values(actual)
        if p is None or a is None:
            invalid += 1
            continue
        errors.append(np.abs(np.array(p) - np.array(a)))
    result = {"mae": float("nan"), "evaluated": len(errors), "invalid": invalid}
    if errors:
        per_target = np.mean(errors, axis=0)
        result["mae"] = float(per_target.mean())
        if len(per_target) > 1:
            result["property_mae"] = {p: float(m) for p, m in zip(PROPERTIES[DATASET], per_target)}
    return result


# ============================================================================
# EVALUATION (generation with the fine-tuned checkpoint)
# ============================================================================


def evaluate_checkpoint(checkpoint, rows):

    tokenizer = AutoTokenizer.from_pretrained(MODEL_ID, padding_side="left")
    tokenizer.pad_token = tokenizer.eos_token
    model = AutoModelForCausalLM.from_pretrained(
        checkpoint, torch_dtype="auto", device_map="auto", trust_remote_code=True
    )
    model.config.pad_token_id = tokenizer.eos_token_id
    pipe = pipeline("text-generation", model=model, tokenizer=tokenizer,
                    padding=True, truncation=True, max_length=MAX_LENGTH)

    prompts = [
        tokenizer.apply_chat_template([{"role": "user", "content": mof_id}],
                                      tokenize=False, add_generation_prompt=True)
        for mof_id, _ in rows
    ]
    predictions = []
    for i in tqdm(range(0, len(prompts), EVAL_BATCH_SIZE), desc="generating"):
        outputs = pipe(prompts[i:i + EVAL_BATCH_SIZE], batch_size=EVAL_BATCH_SIZE,
                       return_full_text=False, do_sample=False, max_new_tokens=MAX_NEW_TOKENS)
        predictions += [out[0]["generated_text"] for out in outputs]

    del pipe, model
    torch.cuda.empty_cache()
    return compute_mae(predictions, [label for _, label in rows])


class ValidEvalCallback(TrainerCallback):


    def __init__(self, valid_rows):
        self.valid_rows = valid_rows

    def on_save(self, args, state, control, **kwargs):
        result = evaluate_checkpoint(get_last_checkpoint(OUTPUT_DIR), self.valid_rows)
        line = f"Valid @ step {state.global_step} (epoch {state.epoch:.0f}) -> {json.dumps(result)}"
        print(line)
        with open(RESULTS_FILE, "a") as f:
            f.write(line + "\n")
        return control


# ============================================================================
# TRAINING
# ============================================================================


def train(train_rows, valid_rows):
    train_dataset = HF_Dataset.from_list([
        {"messages": [{"role": "user", "content": mof_id}, {"role": "assistant", "content": label}]}
        for mof_id, label in train_rows
    ]).shuffle(seed=SEED)

    model = AutoModelForCausalLM.from_pretrained(
        MODEL_ID, torch_dtype=torch.bfloat16, device_map="auto", local_files_only=True
    )
    args = SFTConfig(
        output_dir=OUTPUT_DIR,
        per_device_train_batch_size=TRAIN_BATCH_SIZE,
        seed=SEED,
        max_steps=-1,
        bf16=True,  # bf16 needs A100/H100; use fp16 on V100
        save_strategy="epoch",
        save_only_model=True,
        save_total_limit=1,
        learning_rate=LEARNING_RATE,
        warmup_steps=WARMUP_STEPS,
        neftune_noise_alpha=5,
        gradient_checkpointing=GRADIENT_CHECKPOINTING,
        max_length=MAX_LENGTH,
        logging_steps=500,
        completion_only_loss=False,
        num_train_epochs=NUM_TRAIN_EPOCHS,
        packing=False,
    )
    trainer = SFTTrainer(model=model, train_dataset=train_dataset, args=args,
                         callbacks=[ValidEvalCallback(valid_rows)])
    trainer.train()
    print("Training finished")
    del trainer, model
    torch.cuda.empty_cache()


def main():
    if DATASET not in PROPERTIES:
        raise ValueError(f"DATASET must be one of {list(PROPERTIES)}, got '{DATASET}'")
    splits = load_splits()

    if os.path.isdir(OUTPUT_DIR) and get_last_checkpoint(OUTPUT_DIR):
        print(f"Checkpoint found in {OUTPUT_DIR}: skipping training")
    else:
        print(f"Fine-tuning {MODEL_ID}\nOutput directory: {OUTPUT_DIR}")
        os.makedirs(OUTPUT_DIR, exist_ok=True)
        train(splits["train"], splits["valid"])

    # Final evaluation on the test split, after the last epoch.
    result = evaluate_checkpoint(get_last_checkpoint(OUTPUT_DIR), splits["test"])
    print(f"\nTEST RESULTS: {json.dumps(result, indent=2)}")
    with open(os.path.join(OUTPUT_DIR, "test_results.json"), "w") as f:
        json.dump({"dataset": DATASET, "model_id": MODEL_ID, "test": result}, f, indent=2)
    with open(RESULTS_FILE, "a") as f:
        f.write(f"Test -> {json.dumps(result)}\n")


if __name__ == "__main__":
    main()
