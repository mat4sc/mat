First run the following command : pip3 install numpy scipy pandas transformers trl tensorboard peft

hmof.csv and qmof.csv store the pre-processed descriptors from CIFs file since the CIF files size is over 1GB. It has also the MOFid with is identical to MOFormer split. Each csv file has train/valid/test split. The following script validate several claims in this work:

- sft_mof_multimodal_cross_attention.py demonstrate the main fusion method used in our multimodal validating that descriptors help LLM as you can compare it with generative or regression scripts.
- sft_mof_llm_regression.py validate that compact small LLM with full finetuning outperform both CGCNN and MOFormer
- sft_mof_llm_generative .py main approach used in this work.
- sft_mof_multimodal_attnpool_concat.py the proposed architecture by reviewer A1Qx which suggest "A learned attention-pooling (e.g., a single learnable query) + concatenation baseline would isolate this and is cheap given the frozen backbone.". The comparison between this method and cross attention especially at earlies steps on the validation set support our claims about the cross attention vs concatenation.


Please note that the evaluation during the fine-tuning occur on the validation set and the final model uses the test set. We do not use early stopping or use the best checkpoint in the middle.
For fast PoC implementation use ibm-granite/granite-4.0-350m.

We have commitment to release the following upon the acceptance of the work :
1. all pre-trained models
2. all codes for ablation study
3. pre-processing code to construct the pre-training corpora (This will help other domains such as Polymer and chemical replicating our results)
4. Pre-Training code on PubChem and MOF articles.

Please note that we maintain the anonymity policy and all the name of the models used in the script is the official names for the models from huggingface hub (e.g ibm-granite/granite-4.0-350m).

