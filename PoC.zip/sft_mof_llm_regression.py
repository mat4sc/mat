
import json
import os
import warnings

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import Dataset
from transformers import AutoConfig, AutoModel, AutoTokenizer, Trainer, TrainingArguments, set_seed
from transformers.trainer_utils import get_last_checkpoint

warnings.filterwarnings("ignore")

# ============================================================================
# CONFIGURATION
# ============================================================================

DATASET = "hmof"  # "qmof" or "hmof"

LLM_TUNING = "lora"  # "full" (all LLM weights + head) or "lora" (LoRA adapters + head; needs `pip install peft`)


LLM_MODEL = "ibm-granite/granite-4.0-350m"
#LLM_MODEL = "ibm-granite/granite-3.3-2b-instruct"



DATA_DIR = os.path.dirname(os.path.abspath(__file__))  # folder containing this script and {DATASET}.csv
MAX_LENGTH = 512

NUM_EPOCHS = 100
BATCH_SIZE = 24
EVAL_BATCH_SIZE = 32
LEARNING_RATE = 3e-5
WEIGHT_DECAY = 0.01
WARMUP_STEPS = 100
LOGGING_STEPS = 1000
EVAL_STEPS = 1000
SAVE_STEPS = 1000
NUM_WORKERS = 8
BF16 = True
SEED = 42

# LoRA settings (only used when LLM_TUNING == "lora").
LORA = {"r": 16, "alpha": 32, "dropout": 0.05, "target_modules": "all-linear"}

# Regression head on top of the pooled LLM embedding.
HEAD = {"hidden_dims": [512, 128], "dropout": 0.05}

# ============================================================================
# TASKS
# ============================================================================

TARGETS = {
    "qmof": ["band_gap"],
    "hmof": ["CH4_0.05", "CH4_0.5", "CH4_2.5", "CO2_0.05", "CO2_0.5", "CO2_2.5"],
}


def output_dir_name():
    llm = [p for p in LLM_MODEL.rstrip("/").split("/") if not p.startswith("checkpoint")][-1]
    llm = llm.replace("-", "_").replace(".", "_")
    return f"{llm}_{DATASET.upper()}_{LLM_TUNING}_{NUM_EPOCHS}E_{BATCH_SIZE}Batch_seed{SEED}"


# ============================================================================
# DATASET
# ============================================================================

class MOFDataset(Dataset):


    def __init__(self, split, tokenizer):
        table = pd.read_csv(os.path.join(DATA_DIR, f"{DATASET}.csv"))
        data = table[table["split"] == split].reset_index(drop=True)
        if data.empty:
            raise ValueError(f"No rows with split == '{split}' in {DATASET}.csv")
        targets = TARGETS[DATASET]
        absent = [c for c in targets + ["mof_id"] if c not in data.columns]
        if absent:
            raise ValueError(f"{DATASET}.csv is missing columns: {absent}")

        labels = data[targets].to_numpy(np.float32)
        self.mof_ids = data["mof_id"].astype(str).tolist()
        self.labels = torch.tensor(labels[:, 0] if len(targets) == 1 else labels)
        self.tokenizer = tokenizer

    def __len__(self):
        return len(self.mof_ids)

    def __getitem__(self, idx):
        enc = self.tokenizer(self.mof_ids[idx], max_length=MAX_LENGTH, padding="max_length",
                             truncation=True, return_tensors="pt")
        return {
            "input_ids": enc["input_ids"].squeeze(0),
            "attention_mask": enc["attention_mask"].squeeze(0),
            "labels": self.labels[idx],
        }


# ============================================================================
# MODEL
# ============================================================================

class MOFPredictor(nn.Module):


    def __init__(self, num_outputs):
        super().__init__()
        if LLM_TUNING not in ("full", "lora"):
            raise ValueError(f"LLM_TUNING must be 'full' or 'lora', got '{LLM_TUNING}'")
        print(f"Loading LLM: {LLM_MODEL} (tuning: {LLM_TUNING})")
        self.llm = AutoModel.from_pretrained(LLM_MODEL)  # "full": all LLM weights are trained
        hidden_size = AutoConfig.from_pretrained(LLM_MODEL).hidden_size

        if LLM_TUNING == "lora":
            from peft import LoraConfig, get_peft_model  # imported here so peft is only needed for LoRA
            self.llm = get_peft_model(self.llm, LoraConfig(
                r=LORA["r"], lora_alpha=LORA["alpha"], lora_dropout=LORA["dropout"],
                target_modules=LORA["target_modules"]))  # freezes the base LLM, trains LoRA adapters

        dims = [hidden_size] + HEAD["hidden_dims"]
        layers = [nn.LayerNorm(dims[0])]
        for i in range(len(dims) - 1):
            layers += [nn.Linear(dims[i], dims[i + 1]), nn.GELU(), nn.Dropout(HEAD["dropout"])]
        layers.append(nn.Linear(dims[-1], num_outputs))
        self.regression_head = nn.Sequential(*layers)

        trainable = sum(p.numel() for p in self.parameters() if p.requires_grad)
        print(f"Trainable parameters: {trainable:,} | outputs: {num_outputs}")

    def forward(self, input_ids, attention_mask):
        tokens = self.llm(input_ids=input_ids, attention_mask=attention_mask).last_hidden_state
        mask = attention_mask.unsqueeze(-1).to(tokens.dtype)
        pooled = (tokens * mask).sum(dim=1) / mask.sum(dim=1).clamp(min=1)
        return self.regression_head(pooled.float()).squeeze(-1)


# ============================================================================
# TRAINING AND EVALUATION
# ============================================================================

class MOFTrainer(Trainer):


    def compute_loss(self, model, inputs, return_outputs=False, *, num_items_in_batch=None):
        labels = inputs.pop("labels")
        outputs = model(**inputs)
        loss = torch.nn.functional.mse_loss(outputs, labels)
        return (loss, outputs) if return_outputs else loss

    def prediction_step(self, model, inputs, prediction_loss_only, ignore_keys=None):
        labels = inputs.pop("labels")
        with torch.no_grad():
            outputs = model(**inputs)
            loss = torch.nn.functional.mse_loss(outputs, labels)
        return (loss, outputs, labels)


def make_compute_metrics(targets):
    def compute_metrics(eval_pred):
        preds, labels = eval_pred
        preds = np.asarray(preds, dtype=np.float64).reshape(len(labels), -1)
        labels = np.asarray(labels, dtype=np.float64).reshape(len(labels), -1)
        err = preds - labels
        task_mae = np.abs(err).mean(axis=0)  # one MAE per target
        mse = float((err ** 2).mean())
        r2 = 1.0 - (err ** 2).sum() / ((labels - labels.mean()) ** 2).sum()
        metrics = {"mae": float(task_mae.mean()), "mse": mse, "rmse": mse ** 0.5, "r2": float(r2)}
        if len(targets) > 1:
            metrics.update({f"mae_{name}": float(m) for name, m in zip(targets, task_mae)})
        return metrics
    return compute_metrics


def main():
    if DATASET not in TARGETS:
        raise ValueError(f"DATASET must be one of {list(TARGETS)}, got '{DATASET}'")
    targets = TARGETS[DATASET]
    out_dir = output_dir_name()
    is_main = int(os.environ.get("RANK", 0)) == 0

    set_seed(SEED)
    if is_main:
        print(f"Dataset: {DATASET} | targets: {targets} | LLM tuning: {LLM_TUNING}")
        print(f"Output directory: {out_dir}")
    os.makedirs(out_dir, exist_ok=True)

    tokenizer = AutoTokenizer.from_pretrained(LLM_MODEL)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    train_ds = MOFDataset("train", tokenizer)
    valid_ds = MOFDataset("valid", tokenizer)
    test_ds = MOFDataset("test", tokenizer)
    if is_main:
        print(f"Samples: train={len(train_ds)} valid={len(valid_ds)} test={len(test_ds)}")

    model = MOFPredictor(num_outputs=len(targets))

    args = TrainingArguments(
        output_dir=out_dir,
        num_train_epochs=NUM_EPOCHS,
        per_device_train_batch_size=BATCH_SIZE,
        per_device_eval_batch_size=EVAL_BATCH_SIZE,
        learning_rate=LEARNING_RATE,
        weight_decay=WEIGHT_DECAY,
        warmup_steps=WARMUP_STEPS,
        logging_steps=LOGGING_STEPS,
        eval_strategy="steps",
        eval_steps=EVAL_STEPS,
        save_strategy="steps",
        save_steps=SAVE_STEPS,
        save_total_limit=1,
        bf16=torch.cuda.is_available() and BF16,
        dataloader_num_workers=NUM_WORKERS,
        remove_unused_columns=False,
        report_to="tensorboard",
        seed=SEED,
        ddp_find_unused_parameters=False,
    )
    trainer = MOFTrainer(
        model=model,
        args=args,
        train_dataset=train_ds,
        eval_dataset=valid_ds,  # evaluation during training uses the validation split
        compute_metrics=make_compute_metrics(targets),
    )

    trainer.train(resume_from_checkpoint=get_last_checkpoint(out_dir))

    trainer.save_model(os.path.join(out_dir, "final_model"))
    if is_main:
        tokenizer.save_pretrained(os.path.join(out_dir, "final_model"))

    # Final evaluation on the test split, after the last epoch.
    test_metrics = trainer.evaluate(eval_dataset=test_ds, metric_key_prefix="test")
    if is_main:
        print("\nTEST RESULTS")
        for name, value in test_metrics.items():
            print(f"  {name}: {value}")
        with open(os.path.join(out_dir, "test_results.json"), "w") as f:
            json.dump({"dataset": DATASET, "llm_tuning": LLM_TUNING, "test": test_metrics}, f, indent=2)


if __name__ == "__main__":
    main()
